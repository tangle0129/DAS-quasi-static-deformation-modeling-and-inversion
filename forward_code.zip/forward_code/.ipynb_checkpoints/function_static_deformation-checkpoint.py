import numpy as np
import numpy.matlib
import matplotlib.pylab as plt
from scipy.sparse import coo_matrix
from numpy.linalg import inv
from scipy.interpolate import pchip_interpolate
from scipy.interpolate import Akima1DInterpolator
from scipy.special import jv
import sys
from multiprocessing.dummy import Pool as ThreadPool 
import os
#import numba
from numba import njit, prange
from numpy import reshape
from numpy.matlib import repmat
from numpy import concatenate
from numpy import dot
from numpy import exp
from numpy import size
from numpy import arange
from numpy import sqrt
from numpy import sum
import time
from scipy import interpolate
from numpy.linalg import solve
from scipy.sparse.linalg import spsolve
from scipy import signal
import scipy.signal

###########################################################################
# Static deformation modeling of layered media for 3D DAS measurements    #
# by Le Tang at IPGP 21.05.2025                                           #
# [1] Tang et al., (2026) Quasi-static strain rate waveform inversion     #
#     from DAS data.                                                      #
###########################################################################
# The original static defromation code is a Matlab package, which is from #                                                              
# [1] Skar et al., (2020). ALVA: An adaptive MATLAB package for layered   #
#     viscoelastic analysis. Journal of Open Source Software, 5(55), 2548.# 
#     https://doi.org/10.21105/joss.02548                                 #
###########################################################################

# define a structure
class structure_alva:
    analysis: str
    bond: str
    N: int
    n: int
    zi: np.array
    nu: np.array
    E: np.array
    kh: np.array
    a: np.array
    q: np.array
    def __init__(self, n0):
        self.Xd=np.empty([n0,3])
    Xl: np.array
    H: float
    Lam1: float
    XipWip: np.array
    ABCD: np.array
    ux: np.array
    uy: np.array
    uz: np.array
    sigx: np.array
    sigy: np.array
    sigz: np.array
    sigxy: np.array
    sigyz: np.array
    sigxz: np.array
    epsx: np.array
    epsy: np.array
    epsz: np.array
    epsxy: np.array
    epsyz: np.array
    epsxz: np.array
    I: np.array
    B0rr: np.array
    B1rr: np.array




def ind2sub(array_shape, ind):
    # Gives repeated indices, replicates matlabs ind2sub
    rows = (ind.astype("int32") % array_shape[0])
    cols = (ind.astype("int32") // array_shape[0])
    for i in range(0,len(rows)):
        if rows[i]==0:
            cols[i]=cols[i]-1
            rows[i]=array_shape[0]-1
        else:
            rows[i]=rows[i]-1
            
    return (rows, cols)


# define the integral coefficients
def lookup_gauss(n,a,b):

    p=2*n-1

    if p<=1:
        wp=2
        xp=0
    else:
        if p<=3 and p>1:
            wp=np.array([1,1])
            xp=np.array([-1, 1])/sqrt(3)
        if p<=5 and p>3:
            wp=np.array([5./9,8./9,5./9])
            xp=np.array([-sqrt(3./5),0,sqrt(3./5)])
        if p<=7 and p>5:
            wp=np.array([0.347854845137454,0.652145154862546,0.652145154862546,0.347854845137454]);     
            xp=np.array([-0.861136311594053,-0.339981043584856,0.339981043584856,0.861136311594053]);
        if p<=9 and p>7:
            wp=np.array([0.236926885056189,0.478628670499366,0.568888888888889,0.478628670499366,0.236926885056189]); 
            xp=np.array([-0.906179845938664,-0.538469310105683,0,0.538469310105683,0.906179845938664]); 
        if p<=11 and p>9:
            wp =np.array([0.171324492379170,0.360761573048139,0.467913934572691,0.467913934572691,0.360761573048139,0.171324492379170]);
            xp =np.array([-0.932469514203152,-0.661209386466264,-0.238619186083197,0.238619186083197,0.661209386466264,0.932469514203152]);
        if p<=13 and p>11:
            wp=np.array([ 0.129484966168870,0.279705391489277,0.381830050505119,0.417959183673469,0.381830050505119,0.279705391489277,0.129484966168870]);
            xp=np.array([-0.949107912342758,-0.741531185599394,-0.405845151377397,0,0.405845151377397,0.741531185599394,0.949107912342758]);
        if p<=15 and p>13:
            wp=np.array([ 0.101228536290376,0.222381034453375,0.313706645877887,0.362683783378362,0.362683783378362,0.313706645877887,0.222381034453375,0.101228536290376]);
            xp=np.array([-0.960289856497536,-0.796666477413627,-0.525532409916329,-0.183434642495650,0.183434642495650,0.525532409916329,0.796666477413627,0.960289856497536]);
        if p<=17 and p>15:        
            wp=np.array([[0.081274388361574],
                         [0.180648160694857],
                         [0.260610696402935],
                         [0.312347077040003],
                         [0.330239355001260],
                         [0.312347077040003],
                         [0.260610696402935],
                         [0.180648160694857],
                         [0.081274388361574]]).T;
            xp=np.array([[-0.968160239507626],
                         [-0.836031107326636],
                         [-0.613371432700590],
                         [-0.324253423403809],
                         [0,0.324253423403809],
                         [0.613371432700590],
                         [0.836031107326636],
                         [0.968160239507626]]).T;
        if p<=19 and p>17:
            wp=np.array([[0.066671344308688],
                         [0.149451349150581],
                         [0.219086362515982],
                         [0.269266719309996],
                         [0.295524224714753],
                         [0.295524224714753],
                         [0.269266719309996],
                         [0.219086362515982],
                         [0.149451349150581],
                         [0.066671344308688]]).T;

            xp=np.array([[-0.973906528517172],
                         [-0.865063366688985],
                         [-0.679409568299024],
                         [-0.433395394129247],
                         [-0.148874338981631],
                         [0.148874338981631],
                         [0.433395394129247],
                         [0.679409568299024],
                         [0.865063366688985],
                         [0.973906528517172]]).T;
        if p<=59 and p>19:
            
            wp=np.array([[0.007968192496167],
                         [0.018466468311091],
                         [0.028784707883323],
                         [0.038799192569627],
                         [0.048402672830594],
                         [0.057493156217619],
                         [0.065974229882181],
                         [0.073755974737705],
                         [0.080755895229420],
                         [0.086899787201083],
                         [0.092122522237786],
                         [0.096368737174644],
                         [0.099593420586795],
                         [0.101762389748406],
                         [0.102852652893559],
                         [0.102852652893559],
                         [0.101762389748406],
                         [0.099593420586795],
                         [0.096368737174644],
                         [0.092122522237786],
                         [0.086899787201083],
                         [0.080755895229420],
                         [0.073755974737705],
                         [0.065974229882181],
                         [0.057493156217619],
                         [0.048402672830594],
                         [0.038799192569627],
                         [0.028784707883323],
                         [0.018466468311091],
                         [0.007968192496167]]).T;
            
            xp=np.array([[-0.996893484074650],
                         [-0.983668123279747],
                         [-0.960021864968308],
                         [-0.926200047429274],
                         [-0.882560535792053],
                         [-0.829565762382768],
                         [-0.767777432104826],
                         [-0.697850494793316],
                         [-0.620526182989243],
                         [-0.536624148142020],
                         [-0.447033769538089],
                         [-0.352704725530878],
                         [-0.254636926167890],
                         [-0.153869913608583],
                         [-0.051471842555318],
                         [0.051471842555318],
                         [0.153869913608583],
                         [0.254636926167890],
                         [0.352704725530878],
                         [0.447033769538089],
                         [0.536624148142020],
                         [0.620526182989243],
                         [0.697850494793316],
                         [0.767777432104826],
                         [0.829565762382768],
                         [0.882560535792053],
                         [0.926200047429274],
                         [0.960021864968308],
                         [0.983668123279747],
                         [0.996893484074650]]).T;
                    

        if p>59:
            print('Gauss points and weights for polynomials of 20 or higher are not implemented yet')

    
    n=size(xp)
    
    wp=dot((b-a)/2,reshape(wp,(1,n)))
    xp=dot((b-a)/2,reshape(xp,(1,n)))+dot((b+a)/2,np.ones([1,n]))
    
    return xp,wp
        

        

def numint_coeff(N,n,Xd,Xl,a,H,B0rr,B1rr):
    xl=len(Xl[:,0])
    xd=len(Xd[:,0])
    

    alpha=repmat(reshape(a,(a.size,1))/H,xd,1)
    Xl=repmat(Xl,xd,1)
    Xd=repmat(Xd,xl,1)

    dx=repmat(arange(1,xd+1),xl,1)


    dx=reshape(dx.T,(1,dx.size))+repmat(arange(0,xd*(xl-1)+1,xd),1,xd)

  
    temp=np.empty([len(dx[0,:]),len(Xd[0,:])])

    for i in range(0,dx.size):
        temp[i,:]=Xd[dx[0,i]-1,:]
    Xd=temp


    r=sqrt( (Xd[:,0]-Xl[:,0])**2+(Xd[:,1]-Xl[:,1])**2 )


    rho=r/H
    
    
    B0r=B0rr[0:N]
    B1r=B1rr[0:N]
   
 
    
    rho_Non0 = np.array(np.nonzero(rho))
    rho_Non0= reshape(rho_Non0,(rho_Non0.size,1))


    n3=rho.size
    n4=alpha.size

    
    temp=repmat(B1r,n4,1)/repmat(alpha,1,N)
    temp1=np.zeros([n3,N])

 

    roots_z=concatenate((temp1,temp),axis=1) 

    temp=repmat(B0r,len(rho_Non0),1)

    rho=reshape(rho,(rho.size,1))
    
    temp=np.empty([rho_Non0.size,1])
    temp1=repmat(B0r,len(rho_Non0),1)
    
    if len(rho_Non0)!=0:
        
        for i in range(0,len(rho_Non0)):
            temp[i,0]=rho[rho_Non0[i,0],0]
            
        temp=repmat(temp,1,N)
        
        
        for i in range(0,len(rho_Non0)):
            roots_z[rho_Non0[i,0],0:N]=temp1[i,:]/temp[i,:] 
    




    #######################################################

    roots_z.sort(axis=1)    
 
    

    indx=np.zeros([n3,N])
    num=0
    for j in range(0,N):
        for i in range(0,n3):
            num=num+1
            indx[i,j]=num


    temp=np.argwhere(rho==0)

    indx[temp[:,0],:]=indx[temp[:,0],:]+n3*N
    
    for i in range(0,rho.size):
        if rho[i,:]==alpha[i,:]:
          
            indx[i,:]=indx[i,:]+arange(0,(N-1)*n3+1,1)
    



    temp=indx*0
    length_roots_z=size(roots_z,0)
    for i in range(0,len(temp[:,0])):
        for j in range(0,len(temp[0,:])):
            int_part=int(indx[i,j]//length_roots_z)
            int_resi=int(indx[i,j]%length_roots_z)
            if int_resi==0:
                temp[i,j]=roots_z[length_roots_z-1,int_part-1]
            else:
                temp[i,j]=roots_z[int_resi-1,int_part]
    
    temp1=np.zeros([n3,1])

    
    seq_z=concatenate((temp1,temp),axis=1)     
    
   
    
    temp=np.array(seq_z[:,0])
    temp1=reshape(temp,(size(temp),1))
    temp=np.array(seq_z[:,1])
    temp2=reshape(temp,(size(temp),1))
    
    xip_z1,wip_z1=lookup_gauss(n,temp1,temp2)

    temp=np.array(seq_z[:,1])
    temp1=reshape(temp,(size(temp),1))
    temp=np.array(seq_z[:,2])
    temp2=reshape(temp,(size(temp),1))

    xip_z2,wip_z2=lookup_gauss(20,temp1,temp2)

    temp=np.array(seq_z[:,2])
    temp1=reshape(temp,(size(temp),1))
    temp=np.array(seq_z[:,3])
    temp2=reshape(temp,(size(temp),1))
    
    xip_z3,wip_z3=lookup_gauss(10,temp1,temp2)
    
   

    seq_z1=seq_z[:,3:-1].T
    seq_z2=seq_z[:,4:].T
    temp=reshape(seq_z1.T,(size(seq_z1,1)*size(seq_z1,0),1))
    temp1=reshape(seq_z2.T,(size(seq_z2,1)*size(seq_z2,0),1))
    xip_z,wip_z=lookup_gauss(5,temp,temp1)

    
    temp=reshape(xip_z,(size(xip_z,1)*size(xip_z,0),1))    
    xip_z=reshape(temp,(n3,size(temp)//n3))

    temp=reshape(wip_z,(size(wip_z,1)*size(wip_z,0),1))    
    wip_z=reshape(temp,(n3,size(temp)//n3))
    


    

   
    xip_z=concatenate((xip_z1,xip_z2,xip_z3,xip_z),axis=1)
    xip_r=xip_z

 
    wip_z=concatenate((wip_z1,wip_z2,wip_z3,wip_z),axis=1)

    wip_r=wip_z


    XipWip=concatenate((xip_z,wip_z,xip_r,wip_r),axis=0)

    return XipWip
    

def arb_func(n,zi,E,nu,alva):

    m = np.array([[1e-10], 
                  [0.05],
                  [0.10], 
                  [0.20], 
                  [0.40], 
                  [0.60], 
                  [0.80], 
                  [1.00], 
                  [1.20], 
                  [1.40], 
                  [1.60],
                  [1.80], 
                  [2.00], 
                  [2.20], 
                  [2.40], 
                  [2.60], 
                  [2.80], 
                  [3.00], 
                  [3.20], 
                  [3.40], 
                  [3.60], 
                  [3.80],
                  [4.00], 
                  [4.20], 
                  [4.40], 
                  [4.60], 
                  [4.80], 
                  [5.00], 
                  [5.50], 
                  [6.00], 
                  [6.50], 
                  [7.00], 
                  [7.50],
                  [8.00], 
                  [8.50], 
                  [9.00], 
                  [9.50], 
                  [10.00], 
                  [11.00], 
                  [12.00], 
                  [13.00], 
                  [14.00], 
                  [15.00],
                  [16.00], 
                  [17.00], 
                  [18.00], 
                  [19.00], 
                  [20.00], 
                  [25.00], 
                  [30.00], 
                  [35.00], 
                  [40.00],
                  [45.00], 
                  [50.00], 
                  [55.00], 
                  [60.00], 
                  [65.00], 
                  [70.00], 
                  [75.00], 
                  [80.00], 
                  [85.00],
                  [90.00], 
                  [95.00], 
                  [100.00], 
                  [110.00], 
                  [120.00], 
                  [130.00], 
                  [140.00], 
                  [150.00],
                  [160.00], 
                  [170.00], 
                  [180.00], 
                  [190.00], 
                  [200.00], 
                  [210.00], 
                  [220.00], 
                  [230.00],
                  [240.00], 
                  [250.00], 
                  [260.00], 
                  [270.00], 
                  [280.00], 
                  [290.00], 
                  [300.00], 
                  [350.00],
                  [400.00], 
                  [450.00], 
                  [500.00], 
                  [600.00], 
                  [700.00], 
                  [800.00], 
                  [900.00], 
                  [1000.00],
                  [2000.00], 
                  [10000.00], 
                  [100000.00]]).T;
    Lm=size(m)

    ONES=np.ones([1,Lm])
    H=zi[-1]
    temp=np.array([0])
    temp1=np.array([np.max(zi)*1e20])


    temp=concatenate((temp,zi,temp1),axis=0)/H

 
    lam=reshape(temp,(size(temp),1))
    
    
    E=reshape(E,(size(E),1))
    nu=reshape(nu,(size(nu),1))
    
    if size(E)<size(zi):
        print('The length of zi is too high or the length of E is too short')
    


    j=arange(1,n,1)
    i=j+1
    temp=dot(np.ones([n-1,1]),ONES)
    temp1=exp(dot(-(lam[i-1]-lam[i-2]),m))
    temp2=-(1-dot(2*nu[j-1],ONES)-dot(lam[i-1],m))
    temp3=(1-dot(2*nu[j-1],ONES)+dot(lam[i-1],m))*temp1
    temp4=-exp(dot(-(lam[i]-lam[i-1]),m))
    temp5=-temp
    temp6=(1-dot(2*nu[j],ONES)-dot(lam[i-1],m))*(-temp4)
    temp7=-(1-dot(2*nu[j],ONES)+dot(lam[i-1],m))



 
    sigmaz=concatenate((temp,temp1,temp2,temp3,temp4,temp5,temp6,temp7),axis=1)
    


    temp=dot(np.ones([n-1,1]),ONES)
    temp1=-exp(dot(-(lam[i-1]-lam[i-2]),m))
    temp2=dot(2*nu[j-1],ONES)+dot(lam[i-1],m)
    temp3=(dot(2*nu[j-1],ONES)-dot(lam[i-1],m))*(-temp1)
    temp4=-exp(dot(-(lam[i]-lam[i-1]),m))
    temp5=temp
    temp6=-(dot(2*nu[j],ONES)+dot(lam[i-1],m))*(-temp4)
    temp7=-(dot(2*nu[j],ONES)-dot(lam[i-1],m))



    taurz=concatenate((temp,temp1,temp2,temp3,temp4,temp5,temp6,temp7),axis=1)

  
    
    temp=dot((1+nu[j-1])/E[j-1],ONES)
    temp1=-dot((1+nu[j-1])/E[j-1],ONES)*exp(dot(-(lam[i-1]-lam[i-2]),m))    
    temp2=-dot((1+nu[j-1])/E[j-1],ONES)*(2-dot(4*nu[j-1],ONES)-dot(lam[i-1],m))
    temp3=-dot((1+nu[j-1])/E[j-1],ONES)*(2-dot(4*nu[j-1],ONES)+dot(lam[i-1],m))*exp(dot(-(lam[i-1]-lam[i-2]),m))
    temp4=-dot((1+nu[j])/E[j],ONES)*exp(dot(-(lam[i]-lam[i-1]),m))
    temp5=dot((1+nu[j])/E[j],ONES)
    temp6=dot((1+nu[j])/E[j],ONES)*(2-dot(4*nu[j],ONES)-dot(lam[i-1],m))*exp(dot(-(lam[i]-lam[i-1]),m))
    temp7=dot((1+nu[j])/E[j],ONES)*(2-dot(4*nu[j],ONES)+dot(lam[i-1],m))




    uz=concatenate((temp,temp1,temp2,temp3,temp4,temp5,temp6,temp7),axis=1)

    temp=dot((1+nu[j-1])/E[j-1],ONES)
    temp1=dot((1+nu[j-1])/E[j-1],ONES)*exp(dot(-(lam[i-1]-lam[i-2]),m))
    temp2=dot((1+nu[j-1])/E[j-1],ONES)*(1+dot(lam[i-1],m))
    temp3=-dot((1+nu[j-1])/E[j-1],ONES)*(1-dot(lam[i-1],m))*exp(dot(-(lam[i-1]-lam[i-2]),m))
    temp4=-dot((1+nu[j])/E[j],ONES)*exp(dot(-(lam[i]-lam[i-1]),m))
    temp5=dot(-(1+nu[j])/E[j],ONES)
    temp6=dot(-(1+nu[j])/E[j],ONES)*(1+dot(lam[i-1],m))*exp(dot(-(lam[i]-lam[i-1]),m))
    temp7=dot((1+nu[j])/E[j],ONES)*(1-dot(lam[i-1],m))


    ur=concatenate((temp,temp1,temp2,temp3,temp4,temp5,temp6,temp7),axis=1)

        

    temp=exp(-m*(lam[1]-lam[0]))
    temp1=ONES
    temp2=-(1-2*nu[0])*exp(-m*(lam[1]-lam[0]))
    temp3=(1-2*nu[0])*ONES
    temp4=np.zeros([1,4*Lm])
    
    temp5=exp(-m*(lam[1]-lam[0]))
    temp6=-ONES
    temp7=2*nu[0]*exp(-m*(lam[1]-lam[0]))
    temp8=2*nu[0]*ONES
    temp9=np.zeros([1,4*Lm])

 
 
    temp_p=concatenate((temp,temp1,temp2,temp3,temp4),axis=1)    


    temp_p1=concatenate((temp5,temp6,temp7,temp8,temp9),axis=1) 

      
    BC0=concatenate((temp_p,temp_p1),axis=0)    

    temp=concatenate((sigmaz,taurz),axis=0)
    
    temp=concatenate((temp,uz),axis=0)
    BCs=concatenate((temp,ur),axis=0)

    
    



    indx_c=repmat(arange(0,Lm,1),8,1)
    indx_c=repmat(arange(1,Lm*(8-1)+2,Lm),1,Lm)+reshape(indx_c.T,(size(indx_c),1)).T
    

    temp=reshape(arange(1,n,1),(1,len(arange(1,n,1))))
    temp1=reshape(arange(n,2*(n-1)+1,1),(1,len(arange(n,2*(n-1)+1,1))))
    temp2=reshape(arange(2*n-1,3*(n-1)+1,1),(1,len(arange(2*n-1,3*(n-1)+1,1))))
    temp3=reshape(arange(3*n-2,4*(n-1)+1,1),(1,len(arange(2*n-1,3*(n-1)+1,1))))

 
    indx_r=concatenate((temp,temp1,temp2,temp3),axis=0)
    


    temp=reshape(indx_r.T,(size(indx_r),1))

    temp1=BC0[:,indx_c-1]
    temp1_0=reshape(temp1,(size(temp1,0),size(temp1,2)))
    temp2=BCs[temp-1,indx_c-1]
    BC=concatenate((temp1_0,temp2),axis=0)


    

    indx=repmat(arange(1,4*n-2+1,1),8,1).T
    a=repmat(arange(0,7+1,1),4*n-2,1)
    c=repmat(arange(0,4*(n-2)+1,4),4,1)
    c=repmat(concatenate((np.zeros([2,1]),reshape(c.T,(size(c),1))),axis=0),8,1)

    indx=reshape(indx.T,(size(indx),1))+(reshape(a.T,(size(a),1))+c)*(4*n-2)*Lm
    
    b=repmat(arange(0,Lm,1),size(indx),1)

    indx=repmat(indx,Lm,1)+reshape(b.T,(size(b),1))*(4*n*Lm+1)*(4*n-2)

    array_shape=np.array([Lm*(4*n-2),4*n*Lm])
    I,J=ind2sub(array_shape,indx)
    
    BCg=coo_matrix((reshape(BC.T,(size(BC),1)).flatten(),(I.flatten(),J.flatten())),shape=(Lm*(4*n-2),4*n*Lm)).toarray()

    
    
    temp=arange(4*n-3,4*n*Lm-3+1,4*n)
    temp=reshape(temp,(1,size(temp)))
    temp1=arange(4*n-1,4*n*Lm-1+1,4*n)
    temp1=reshape(temp1,(1,size(temp1)))

    
    indx_cr=concatenate((temp,temp1),axis=0)

    BCg=np.delete(BCg, indx_cr.T.flatten()-1, 1)

    
    Rhs=np.zeros([4*n-3,1])
    Rhs=concatenate((np.ones([1,1]),Rhs),axis=0)
    Rhs=repmat(Rhs,Lm,1)
    


    ABCD0=spsolve(BCg, Rhs)

    #ABCD0=dot(inv(BCg),Rhs)

    



    ABCD=reshape(ABCD0,(Lm,4*n-2)).T

    temp=ABCD[0:-2,:]
    temp1=np.zeros([1,Lm])
    temp2=ABCD[-2,:]
    temp2=reshape(temp2,(1,size(temp2)))
    temp3=np.zeros([1,Lm])
    temp4=ABCD[-1,:]
    temp4=reshape(temp4,(1,size(temp4)))


    
    
    ABCD=concatenate((temp,temp1,temp2,temp3,temp4,m),axis=0)


    return ABCD

#######################accelerate with numba#########

@njit
def linear_interp(x, xp, fp):
    n = len(xp)
    out = np.empty_like(x)
    for i in range(len(x)):
        xi = x[i]
        # Clamp out of bounds
        if xi <= xp[0]:
            out[i] = fp[0]
        elif xi >= xp[n-1]:
            out[i] = fp[n-1]
        else:
            # Find index j where xp[j] <= xi < xp[j+1]
            for j in range(n - 1):
                if xp[j] <= xi < xp[j + 1]:
                    t = (xi - xp[j]) / (xp[j + 1] - xp[j])
                    out[i] = fp[j] + t * (fp[j + 1] - fp[j])
                    break
    return out


def arb_func_interp(n,xip,ABCD):

    m=ABCD[-1,:]
    ABCDt=ABCD[0:-1,:]
    ABCDi=np.zeros([size(ABCDt,0),size(xip)])
    

    for i in prange(0,4*n,1):

        #ABCDi[i,:]=pchip_interpolate(m,ABCDt[i,:],xip)
        
        
        ABCDi[i, :] = linear_interp(xip, m, ABCDt[i, :])

        

    
    return ABCDi


'''
def arb_func_interp(n,xip,ABCD):

    m=ABCD[-1,:]
    ABCDt=ABCD[0:-1,:]
    ABCDi=np.zeros([size(ABCDt,0),size(xip)])

    for i in range(0,4*n,1):

        #ABCDi[i,:]=pchip_interpolate(m,ABCDt[i,:],xip)
        
        f = interpolate.interp1d(m, ABCDt[i,:],kind='linear')
        ABCDi[i,:]=f(xip)

        

    
    return ABCDi
'''

def LET_response(alva):

    Xd=alva.Xd
    Xl=alva.Xl
    a=alva.a
    q=alva.q
    E=alva.E
    nu=alva.nu
    zi=alva.zi

    XipWip=alva.XipWip
    ABCD=alva.ABCD

    H=zi[-1]

    if len(E)!=len(nu):
        print('The size of E is not equal to nu')

    xl=size(Xl,0)
    xd=size(Xd,0)
    


    if size(q,0)<xl or size(a,0)<xl:
        print('Number of q or a is lower than the number of load coordinates!')

    a=reshape(a,(size(a),1))
    q=reshape(q,(size(q),1))
    zi=reshape(zi,(1,size(zi)))
    
    Xl=repmat(Xl,xd,1)
    q=repmat(q,xd,1)
    alpha=repmat(a/H,xd,1)
    Xd=repmat(Xd,xl,1)

    dx=repmat(arange(1,xd+1,1),xl,1)

    dx=reshape(dx.T,(size(dx),1)).T+repmat(arange(0,xd*(xl-1)+1,xd),1,xd)

    Xd=Xd[dx.flatten()-1,:]
    z=Xd[:,2]
    z=reshape(z,(size(z),1))
    
    r= sqrt((Xd[:,0]-Xl[:,0])**2+(Xd[:,1]-Xl[:,1])**2)
    r=reshape(r,(size(r),1))

    rho=r/H
    
    for i in range(0,size(rho)):
        if rho[i,0]==0:
            rho[i,0]=1e-20

    lrho=size(rho)
    xip_z=XipWip[0*lrho:1*lrho,:]
    wip_z=XipWip[1*lrho:2*lrho,:]
    xip_r=XipWip[2*lrho:3*lrho,:]
    wip_r=XipWip[3*lrho:4*lrho,:]

    nz=size(xip_z,1)
    temp=repmat(z,1,size(zi))
    temp1=repmat(zi,size(rho),1)
    temp2=temp
    
    for i in range(0,size(temp,0)):
        for j in range(0,size(temp,1)):
            if temp[i,j]>temp1[i,j]:
                temp2[i,j]=1
            else:
                temp2[i,j]=0
    layer_no=sum(temp2,axis=1)+1
    layer_no=reshape(layer_no,(1,size(layer_no)))

    Lami=np.zeros([size(rho),1])
    Lami1=np.zeros([size(rho),1])

    for i in range(0,size(rho)):
        
        if layer_no[0,i]>size(zi):
            Lami[i]=zi[0,-1]/H*1e20
        else:
            Lami[i]=zi[0,(layer_no[0,i]-1).astype("int32")]/H

        if layer_no[0,i]==1:
            Lami1[i]=0
        else:
            Lami1[i]=zi[0,(layer_no[0,i]-2).astype("int32")]/H
            
    Aa=np.zeros([size(rho),nz])
    Bb=np.zeros([size(rho),nz])
    Cc=np.zeros([size(rho),nz])
    Dd=np.zeros([size(rho),nz])


    
    

    for j in range(0,size(rho)):


        ABCDz=arb_func_interp(size(E),xip_z[j,:],ABCD)

        Aa[j,:]=ABCDz[((layer_no[0,j]-1)*4+0).astype("int32"),:]
        Bb[j,:]=ABCDz[((layer_no[0,j]-1)*4+1).astype("int32"),:]
        Cc[j,:]=ABCDz[((layer_no[0,j]-1)*4+2).astype("int32"),:]
        Dd[j,:]=ABCDz[((layer_no[0,j]-1)*4+3).astype("int32"),:]
        


    Nu=nu[(layer_no[0,:]-1).astype("int32")]
    Nu=reshape(Nu,(size(Nu),1))
    Ee=E[(layer_no[0,:]-1).astype("int32")]
    Ee=reshape(Ee,(size(Ee),1))

    x1=2**(-20)
    Iz1=exp(-x1*xip_z**2)
    Iz2=exp(-(x1/2)*xip_z**2)
    Ir1=exp(-x1*xip_r**2)
    Ir2=exp(-(x1/2)*xip_r**2)

    alpha_nz=repmat(alpha,1,nz)
    rho_nz=repmat(rho,1,nz)
    Nu_nz=repmat(Nu,1,nz)
    zH_nz=repmat(z/H,1,nz)
    Lami_zH_nz=repmat(Lami-z/H,1,nz)
    zH_Lami1_nz=repmat(z/H-Lami1,1,nz)
    
    temp=jv(0,xip_z*rho_nz)
    temp1=(Aa-Cc*(2-4*Nu_nz-xip_z*zH_nz))*exp(-xip_z*Lami_zH_nz)
    temp2=(Bb+Dd*(2-4*Nu_nz+xip_z*zH_nz))*exp(-xip_z*zH_Lami1_nz)
    uzs=temp*(temp1-temp2)

    
    temp=sum(uzs*jv(1,xip_z*alpha_nz)/xip_z*wip_z*Iz1,axis=1)
    temp=reshape(temp,(size(temp),1))
    Iuz1=q*alpha*(-1)*H*(1+Nu)/Ee*temp

    temp=sum(uzs*jv(1,xip_z*alpha_nz)/xip_z*wip_z*Iz2,axis=1)
    temp=reshape(temp,(size(temp),1))
    Iuz2=q*alpha*(-1)*H*(1+Nu)/Ee*temp

    uz=(4*Iuz2-Iuz1)/3.


    temp=jv(1,xip_r*rho_nz)
    temp1=(Aa+Cc*(1+xip_r*zH_nz))*exp(-xip_r*Lami_zH_nz)
    temp2=(Bb-Dd*(1-xip_z*zH_nz))*exp(-xip_r*zH_Lami1_nz)
    urs=temp*(temp1+temp2)

    temp=sum(urs*jv(1,xip_r*alpha_nz)/xip_r*wip_r*Ir1,axis=1)
    temp=reshape(temp,(size(temp),1))
    Iur1=q*alpha*H*(1+Nu)/Ee*temp

    temp=sum(urs*jv(1,xip_r*alpha_nz)/xip_r*wip_r*Ir2,axis=1)
    temp=reshape(temp,(size(temp),1))
    Iur2=q*alpha*H*(1+Nu)/Ee*temp

    ur=(4*Iur2-Iur1)/3.


    ########## stress ##########3

    temp=-xip_z*jv(0,xip_z*rho_nz)
    temp1=(Aa-Cc*(1-2*Nu_nz-xip_z*zH_nz))*exp(-xip_z*Lami_zH_nz)    
    temp2=(Bb+Dd*(1-2*Nu_nz+xip_z*zH_nz))*exp(-xip_z*zH_Lami1_nz)      
    sigma_zs=temp*(temp1+temp2)

    temp=sum(sigma_zs*jv(1,xip_z*alpha_nz)/xip_z*wip_z*Iz1,axis=1)
    temp=reshape(temp,(size(temp),1))
    Isz1=q*alpha*temp
    
    temp=sum(sigma_zs*jv(1,xip_z*alpha_nz)/xip_z*wip_z*Iz2,axis=1)
    temp=reshape(temp,(size(temp),1))
    Isz2=q*alpha*temp

    sigma_z=(4*Isz2-Isz1)/3.
  
   
    temp=xip_r*jv(0,xip_r*rho_nz)-(jv(1,xip_r*rho_nz)/rho_nz)
    temp1=(Aa+Cc*(1+xip_r*zH_nz))*exp(-xip_r*Lami_zH_nz)
    temp2=(Bb-Dd*(1-xip_r*zH_nz))*exp(-xip_r*zH_Lami1_nz)
    temp3=2*Nu_nz*xip_r*jv(0,xip_r*rho_nz)
    temp4=Cc*exp(-xip_r*Lami_zH_nz)-Dd*exp(-xip_r*zH_Lami1_nz)
    sigma_rs=temp*(temp1+temp2)+temp3*temp4

    temp=sum(sigma_rs*jv(1,xip_r*alpha_nz)/xip_r*wip_r*Ir1,axis=1)
    temp=reshape(temp,(size(temp),1))    
    Isr1=q*alpha*temp

    temp=sum(sigma_rs*jv(1,xip_r*alpha_nz)/xip_r*wip_r*Ir2,axis=1)
    temp=reshape(temp,(size(temp),1))    
    Isr2=q*alpha*temp
    sigma_r=(4*Isr2-Isr1)/3.

    temp=jv(1,xip_r*rho_nz)/rho_nz
    temp1=(Aa+Cc*(1+xip_r*zH_nz))*exp(-xip_r*Lami_zH_nz)
    temp2=(Bb-Dd*(1-xip_r*zH_nz))*exp(-xip_r*zH_Lami1_nz)
    temp3=2*Nu_nz*xip_r*jv(0,xip_r*rho_nz)
    temp4=Cc*exp(-xip_r*Lami_zH_nz)-Dd*exp(-xip_r*zH_Lami1_nz)
    sigma_thetas=temp*(temp1+temp2)+temp3*temp4

    temp=sum(sigma_thetas*jv(1,xip_r*alpha_nz)/xip_r*wip_r*Ir1,axis=1)
    temp=reshape(temp,(size(temp),1))    
    Isr1=q*alpha*temp    
    
    temp=sum(sigma_thetas*jv(1,xip_r*alpha_nz)/xip_r*wip_r*Ir2,axis=1)
    temp=reshape(temp,(size(temp),1))    
    Isr2=q*alpha*temp
    sigma_theta=(4*Isr2-Isr1)/3.    


    temp=xip_z*jv(1,xip_z*rho_nz)
    temp1=(Aa+Cc*(2*Nu_nz+xip_z*zH_nz))*exp(-xip_z*Lami_zH_nz)
    temp2=(Bb-Dd*(2*Nu_nz-xip_z*zH_nz))*exp(-xip_z*zH_Lami1_nz)

    tau_rzs=temp*(temp1-temp2)
    
    temp=sum(tau_rzs*jv(1,xip_z*alpha_nz)/xip_z*wip_z*Iz1,axis=1)
    temp=reshape(temp,(size(temp),1))    
    Itr1=q*alpha*temp 
    
    temp=sum(tau_rzs*jv(1,xip_z*alpha_nz)/xip_z*wip_z*Iz2,axis=1)
    temp=reshape(temp,(size(temp),1))    
    Itr2=q*alpha*temp
    tau_rz=(4*Itr2-Itr1)/3.

    T=np.zeros([3*size(r),3*size(r)])
    T[-1,-1]=(3*3-4)*size(r)

    temp=Xd[:,0]-Xl[:,0]
    COS=reshape(temp,(size(temp),1))/r

    temp=Xd[:,1]-Xl[:,1]
    SIN=reshape(temp,(size(temp),1))/r


  
    
    temp=np.argwhere(r==0)   
    COS[temp[:,0],0]=1
    
    temp=np.argwhere(r==0)   
    SIN[temp[:,0],0]=0

    
    num=0
    for i in range(0,3*size(r),3):
        
        T[i,i]=COS[num,0]
        num=num+1
        
    num=0
    for i in range(0,3*size(r),3):
        
        T[i+1,i]=-SIN[num,0]
        num=num+1

        
    num=0
    for i in range(0,3*size(r),3):
        
        T[i,i+1]=SIN[num,0]
        num=num+1
        
    
    num=0
    for i in range(1,3*size(r),3):
        
        T[i,i]=COS[num,0]
        num=num+1   
    

    num=0
    for i in range(2,3*size(r),3):
        
        T[i,i]=1
        num=num+1  


    u1=np.zeros([3*size(r),1])
    u1[::3,0]=ur[:,0]
    u1[2::3,0]=uz[:,0]


    sig1=np.zeros([3*size(r),3*size(r)])
    sig1[-1,-1]=(3*3-4)*size(r)

    num=0
    for i in range(0,3*size(r),3):
        
        sig1[i,i]=sigma_r[num,0]
        num=num+1
        
    num=0
    for i in range(1,3*size(r),3):
        
        sig1[i,i]=sigma_theta[num,0]
        num=num+1 


    num=0
    for i in range(2,3*size(r),3):
        
        sig1[i,i]=sigma_z[num,0]
        num=num+1 

    num=0
    for i in range(0,3*size(r),3):
        
        sig1[i+2,i]=tau_rz[num,0]
        num=num+1


    num=0
    for i in range(0,3*size(r),3):
        
        sig1[i,i+2]=tau_rz[num,0]
        num=num+1
    

    u1=dot(T.T,u1)
    u=u1

    sig1=dot(dot(T.T,sig1),T)
    sigm=sig1


    dos=np.zeros([6*xd*xl,1])
    temp=arange(0,6*xd*xl-5,6)
    dos[temp,0]=arange(1,9*xd*xl*size(r)+1,9*xd*xl+3)
    temp1=arange(1,6*xd*xl-4,6)
    dos[temp1,0]=dos[temp,0]+3*xd*xl+1
    temp1=arange(2,6*xd*xl-3,6)
    dos[temp1,0]=dos[temp,0]+2*3*xd*xl+2
    temp1=arange(3,6*xd*xl-2,6)
    dos[temp1,0]=dos[temp,0]+1
    temp1=arange(4,6*xd*xl-1,6)
    temp=arange(1,6*xd*xl-4,6)
    dos[temp1,0]=dos[temp,0]+1

    temp1=arange(5,6*xd*xl,6)
    temp=arange(0,6*xd*xl-5,6)
    dos[temp1,0]=dos[temp,0]+2

    sigv=np.zeros([6*xd*xl,1])

    length_sigm=size(sigm,0)

    for i in range(0,6*xd*xl):
        
        int_part=int(dos[i,0]//length_sigm)
        int_resi=int(dos[i,0]%length_sigm)
        if int_resi==0:
            sigv[i,0]=sigm[length_sigm-1,int_part-1]
        else:
            sigv[i,0]=sigm[int_resi-1,int_part]


    unos=np.zeros([3*xd*xl,1])
    unos[0:xl,0]=arange(1,9*xl*xd+1,9*xd)
    unos[xl:2*xl,0]=unos[0:xl,0]+3*xd+1
    unos[2*xl:3*xl,0]=unos[0:xl,0]+2*3*xd+2
    for i in range(1,xd,1):
        unos[3*xl+1+3*xl*(i-1)-1:3*xl+3*xl*i,0]=unos[0:3*xl,0]+i*(3*xd*3*xl+3)


    Txyz=np.zeros([3*xd,3*size(r)])
    Txyz[-1,-1]=size(unos)
 
    for i in range(0,3*xd*xl):
        
        int_part=int(unos[i,0]//(3*xd))
        int_resi=int(unos[i,0]%(3*xd))
        if int_resi==0:
            Txyz[(3*xd)-1,int_part-1]=1.
        else:
            Txyz[int_resi-1,int_part]=1.
        

    tres=np.zeros([6*xd*xl,1])
    tres[0:xl,0]=arange(1,9*4*xl*xd+1,9*4*xd)
    tres[xl:2*xl,0]=tres[0:xl,0]+6*xd+1
    tres[2*xl:3*xl,0]=tres[0:xl,0]+2*6*xd+2

    tres[3*xl:4*xl,0]=tres[0:xl,0]+3*6*xd+3
    tres[4*xl:5*xl,0]=tres[0:xl,0]+4*6*xd+4
    tres[5*xl:6*xl,0]=tres[0:xl,0]+5*6*xd+5

    for i in range(1,xd):
        tres[6*xl+1+6*xl*(i-1)-1:6*xl+6*xl*i,0]=tres[0:6*xl,0]+i*(6*xd*6*xl+6)


    Mxyz=np.zeros([6*xd,6*size(r)])
    Mxyz[-1,-1]=np.size(tres)

    for i in range(0,6*xd*xl):
        
        int_part=int(tres[i,0]//(6*xd))
        int_resi=int(tres[i,0]%(6*xd))
        if int_resi==0:
            Mxyz[(6*xd)-1,int_part-1]=1.
        else:
            Mxyz[int_resi-1,int_part]=1.



    u=dot(Txyz,u)
    temp=arange(1,size(u)-2+1,3)
    alva.ux=reshape(u[temp-1,0],(size(u[temp-1,0]),1))
    #alva.ux=temp
    temp=arange(2,size(u)-1+1,3)
    alva.uy=reshape(u[temp-1,0],(size(u[temp-1,0]),1))
    #alva.uy=temp
    temp=arange(3,size(u)+1,3)
    alva.uz=reshape(u[temp-1,0],(size(u[temp-1,0]),1))
    #alva.uz=temp


    sig=dot(-Mxyz,sigv)

    temp=arange(1,size(sig)-5+1,6)
    alva.sigx=reshape(sig[temp-1,0],(size(sig[temp-1,0]),1))
    #alva.sigx=temp
    temp=arange(2,size(sig)-4+1,6)
    alva.sigy=reshape(sig[temp-1,0],(size(sig[temp-1,0]),1))
    #alva.sigy=temp
    temp=arange(3,size(sig)-3+1,6)
    alva.sigz=reshape(sig[temp-1,0],(size(sig[temp-1,0]),1))
    #alva.sigz=temp
    temp=arange(4,size(sig)-2+1,6)
    alva.sigxy=reshape(sig[temp-1,0],(size(sig[temp-1,0]),1))
    #alva.sigxy=temp
    temp=arange(5,size(sig)-1+1,6)
    alva.sigyz=reshape(sig[temp-1,0],(size(sig[temp-1,0]),1))
    #alva.sigyz=temp
    temp=np.arange(6,size(sig)+1,6)
    alva.sigxz=reshape(sig[temp-1,0],(size(sig[temp-1,0]),1))
    #alva.sigxz=temp

    #strain
    Eel=Ee[::xl,0]
    Eel=reshape(Eel,(size(Eel),1))
    Nul=Nu[::xl,0]
    Nul=reshape(Nul,(size(Nul),1))

 

    alva.epsx=1./Eel*(alva.sigx-Nul*(alva.sigy+alva.sigz))
    alva.epsy=1./Eel*(alva.sigy-Nul*(alva.sigz+alva.sigx))
    alva.epsz=1./Eel*(alva.sigz-Nul*(alva.sigx+alva.sigy))

    alva.epsxy=(1+Nul)/Eel*alva.sigxy
    alva.epsyz=(1+Nul)/Eel*alva.sigyz
    alva.epsxz=(1+Nul)/Eel*alva.sigxz
    

    
    


    return alva

    

def polfit_int(Xd,Xl,a,H,Lam1,XipWip,Nu):

    xl=len(Xl[:,0])
    xd=len(Xd[:,0])
    

    alpha=repmat(reshape(a,(a.size,1))/H,xd,1)
    Xl=repmat(Xl,xd,1)
    Xd=repmat(Xd,xl,1)

    dx=repmat(arange(1,xd+1),xl,1)


    dx=reshape(dx.T,(1,dx.size))+repmat(arange(0,xd*(xl-1)+1,xd),1,xd)


    temp=np.zeros([len(dx[0,:]),len(Xd[0,:])])
 
    for i in range(0,dx.size):
        temp[i,:]=Xd[dx[0,i]-1,:]
    Xd=temp


    r=sqrt( (Xd[:,0]-Xl[:,0])**2+(Xd[:,1]-Xl[:,1])**2 )
 

    rho=r/H    
    rho=reshape(rho,(size(rho),1))

    lrho=size(rho)

    xip_z=XipWip[0*lrho:1*lrho,:]
    wip_z=XipWip[1*lrho:2*lrho,:]
    xip_r=XipWip[2*lrho:3*lrho,:]
    wip_r=XipWip[3*lrho:4*lrho,:]

    nz=size(xip_z,1)

    rho_tep=repmat(rho,1,nz)
    alpha_tep=repmat(alpha,1,nz)
    exp_xip_z=exp(-2*Lam1*xip_z)
    
    temp=jv(0,xip_z*rho_tep)*(xip_z**2*exp_xip_z)
    temp1=sum(temp*jv(1,xip_z*alpha_tep)/xip_z*wip_z,1)
    temp1=reshape(temp1,(size(temp1),1))
    Iz1=alpha*(-1)*H*(1+Nu)*temp1

    temp=jv(0,xip_z*rho_tep)*(xip_z*exp_xip_z)
    temp1=sum(temp*jv(1,xip_z*alpha_tep)/xip_z*wip_z,1)
    temp1=reshape(temp1,(size(temp1),1))
    Iz2=alpha*(-1)*H*(1+Nu)*temp1

    temp=jv(0,xip_z*rho_tep)*(exp_xip_z)
    temp1=sum(temp*jv(1,xip_z*alpha_tep)/xip_z*wip_z,1)
    temp1=reshape(temp1,(size(temp1),1))
    Iz3=alpha*(-1)*H*(1+Nu)*temp1

    temp=jv(0,xip_z*rho_tep)*(-(2-2*Nu))
    temp1=sum(temp*jv(1,xip_z*alpha_tep)/xip_z*wip_z,1)
    temp1=reshape(temp1,(size(temp1),1))
    Iz4=alpha*(-1)*H*(1+Nu)*temp1

    exp_xip_r=exp(-2*Lam1*xip_r)
    
    temp=jv(1,xip_r*rho_tep)*(xip_r**2*exp_xip_r)
    temp1=sum(temp*jv(1,xip_r*alpha_tep)/xip_r*wip_r,1)
    temp1=reshape(temp1,(size(temp1),1))
    Ir1=alpha*H*(1+Nu)*temp1    

    temp=jv(1,xip_r*rho_tep)*(xip_r*exp_xip_r)
    temp1=sum(temp*jv(1,xip_r*alpha_tep)/xip_r*wip_r,1)
    temp1=reshape(temp1,(size(temp1),1))
    Ir2=alpha*H*(1+Nu)*temp1

    temp=jv(1,xip_r*rho_tep)*(exp_xip_r)
    temp1=sum(temp*jv(1,xip_r*alpha_tep)/xip_r*wip_r,1)
    temp1=reshape(temp1,(size(temp1),1))
    Ir3=alpha*H*(1+Nu)*temp1

    temp=jv(1,xip_r*rho_tep)*(-(1-2*Nu))
    temp1=sum(temp*jv(1,xip_r*alpha_tep)/xip_r*wip_r,1)
    temp1=reshape(temp1,(size(temp1),1))
    Ir4=alpha*H*(1+Nu)*temp1

    
 
    I=concatenate((Iz1,Iz2,Iz3,Iz4,Ir1,Ir2,Ir3,Ir4),axis=1)
    

    return I


def arb_func_polfit(E,nu,zi,xip_z,xip_r,lrho,alva):

    xiz = np.argmax(xip_z[:,-1])
    xir = np.argmax(xip_r[:,-1])

    xipz=xip_z[xiz,:]
    xipr=xip_r[xir,:]


    arb_func_plain(size(E),xipz,zi,E,nu,alva)


    

def LET_response_polfit(alva):
    
    Xd=alva.Xd
    Xl=alva.Xl
    a=alva.a
    q=alva.q
    E=alva.E
    nu=alva.nu
    zi=alva.zi

    XipWip=alva.XipWip
    I=alva.I

    H=zi[-1]

    if len(E)!=len(nu):
        print('The size of E is not equal to nu')

    xl=size(Xl,0)
    xd=size(Xd,0)
    


    if size(q,0)<xl or size(a,0)<xl:
        print('Number of q or a is lower than the number of load coordinates!')

    a=reshape(a,(size(a),1))
    q=reshape(q,(size(q),1))
    zi=reshape(zi,(1,size(zi)))
    
    Xl=repmat(Xl,xd,1)
    q=repmat(q,xd,1)
    alpha=repmat(a/H,xd,1)
    Xd=repmat(Xd,xl,1)

    dx=repmat(arange(1,xd+1,1),xl,1)

    dx=reshape(dx.T,(size(dx),1)).T+repmat(arange(0,xd*(xl-1)+1,xd),1,xd)

    Xd=Xd[dx.flatten()-1,:]

    r= sqrt((Xd[:,0]-Xl[:,0])**2+(Xd[:,1]-Xl[:,1])**2)
    r=reshape(r,(size(r),1))

    rho=r/H
    

    lrho=size(rho)
    xip_z=XipWip[0*lrho:1*lrho,:]
    wip_z=XipWip[1*lrho:2*lrho,:]
    xip_r=XipWip[2*lrho:3*lrho,:]
    wip_r=XipWip[3*lrho:4*lrho,:]

    nz=np.size(xip_z,1)   





def init_LET(alva,channel_location,thick_layer,vs,rou,poisson):

    alva.Xd[:,0]=channel_location[:,0]                            # X location of DAS channel (m)
    alva.Xd[:,1]=channel_location[:,1]                            # Y location of DAS channel (m)
    alva.Xd[:,2]=channel_location[:,2]                            # Z location of DAS channel (m)

    thk_dep0=thick_layer*0.0
    for tepp in range(0,len(thick_layer)):
        thk_dep0[tepp]=np.sum(thick_layer[0:(tepp+1)])

  

    alva.zi=thk_dep0[:]                                           # Thickness from the surface to each layer (m) 
    alva.nu=poisson                                               # Poisson's ratio

    alva.E=2*vs**2*rou*(alva.nu+1)                                # Young's Modules (Pa)


    # read the bessel integral coefficients
    with open("B0r_table.txt", "r") as file1:
        f_list = [float(i) for line in file1 for i in line.split(' ') if i.strip()]
        B0rr = np.array(f_list[0:-1])
        
    with open("B1r_table.txt", "r") as file1:
        f_list = [float(i) for line in file1 for i in line.split(' ') if i.strip()]
        B1rr = np.array(f_list[0:-1])   
    
    alva.B0rr=B0rr
    alva.B1rr=B1rr
    

    
    N=alva.N
    n=alva.n
    Xd=alva.Xd
    Xl=alva.Xl
    a=alva.a
    E=alva.E
    nu=alva.nu
    zi=alva.zi
    #general parameters
    H=zi[-1]
    alva.H=H
    Lam1=zi[0]/zi[-1]
    alva.Lam1=Lam1

    




    alva.XipWip=numint_coeff(N,n,Xd,Xl,a,H,alva.B0rr,alva.B1rr)


    
   
  
    alva.ABCD=arb_func(len(E),zi,E,nu,alva)



    alva=LET_response(alva)
    # displacement
    ux=alva.ux                       # ux: x-component displacement (m)
    uy=alva.uy                       # uy: y-component displacement (m)
    uz=alva.uz                       # uz: z-component displacement (m)
    
    # stress
    
    sigx=alva.sigx                   # sigx: (x,x)-component stress (N)
    sigy=alva.sigy                   # sigy: (y,y)-component stress (N)
    sigz=alva.sigz                   # sigz: (z,z)-component stress (N)
    sigxy=alva.sigxy                 # sigxy: (x,y)-component stress (N)
    sigyz=alva.sigyz                 # sigxy: (y,z)-component stress (N)
    sigxz=alva.sigxz                 # sigxy: (x,z)-component stress (N)
    
    # strain
    
    epsx=alva.epsx                   # epsx: (x,x)-component strain 
    epsy=alva.epsy                   # epsy: (y,y)-component strain
    epsz=alva.epsz                   # epsz: (z,z)-component strain
    epsxy=alva.epsxy                 # epsxy: (x,y)-component strain
    epsyz=alva.epsyz                 # epsx: (y,z)-component strain
    epsxz=alva.epsxz                 # epsx: (x,z)-component strain
    
    return ux,uy,uz,sigx,sigy,sigz,sigxy,sigyz,sigxz,epsx,epsy,epsz,epsxy,epsyz,epsxz  


# calculat the vector direction form P1 to P2
def direction_from_points(P1, P2):
    """
    Compute unit direction vector from point P1 to P2.
    """
    P1 = np.array(P1, dtype=float)
    P2 = np.array(P2, dtype=float)

    v = P2 - P1                # direction vector
    norm = np.linalg.norm(v)

    if norm == 0:
        raise ValueError("Points cannot be identical.")

    return v / norm            # unit direction vector

# rotate the 3D strain_tensor to the fiber direction
def normal_strain(strain_tensor, n):
    """
    Compute normal strain in direction n.

    Parameters
    ----------
    strain_tensor : 3x3 array-like
        Symmetric strain tensor:
        [[exx, exy, exz],
         [exy, eyy, eyz],
         [exz, eyz, ezz]]

    n : array-like (length 3)
        Direction vector (does NOT need to be unit length)

    Returns
    -------
    float
        Normal strain in direction n
    """

    strain_tensor = np.array(strain_tensor, dtype=float)
    n = np.array(n, dtype=float)

    # Normalize direction vector
    n = n / np.linalg.norm(n)

    # Compute ε_n = n^T ε n
    return float(n.T @ strain_tensor @ n)


# from the GPS measurement to channel location
def GPS_channel_location(x,y,z,channel_spacing):
    num_p=len(x)
    curve_points=np.zeros([num_p,3])        # for example: the GPS measurement of cable
    
    curve_points[:,0]=x[:]                  # x location (m) 
    curve_points[:,1]=y[:]                  # y location (m)
    curve_points[:,2]=z[:]                  # z location (m)
    
    
    #compute cumulative distances along the curve
    diffs = np.diff(curve_points, axis=0)
    dists = np.linalg.norm(diffs, axis=1)
    cumdist = np.insert(np.cumsum(dists), 0, 0)
    
    num_points = int(cumdist[-1] / channel_spacing) + 1
    
    # Interpolate equally spaced points
    
    equal_dist_points = np.zeros((num_points, 3))
    for i, s in enumerate(np.linspace(0, cumdist[-1], num_points)):
        equal_dist_points[i] = np.array([
            np.interp(s, cumdist, curve_points[:,0]),
            np.interp(s, cumdist, curve_points[:,1]),
            np.interp(s, cumdist, curve_points[:,2])
        ])
    
    return equal_dist_points



def car_wheels(car_location,width,length):
    
    equal_dist_points=car_location
    
    squares_corners = []  # list to store 4 corners for each point
    
    for i, p in enumerate(equal_dist_points):
        # 1. tangent vector along curve
        if i == 0:
            tangent = equal_dist_points[i+1] - p
        elif i == len(equal_dist_points)-1:
            tangent = p - equal_dist_points[i-1]
        else:
            tangent = equal_dist_points[i+1] - equal_dist_points[i-1]
        tangent = tangent / np.linalg.norm(tangent)
    
        # 2. perpendicular vectors for width
        up = np.array([0, 0, 1])
        if np.allclose(tangent, up):
            up = np.array([1, 0, 0])
        perp1 = np.cross(tangent, up)
        perp1 = perp1 / np.linalg.norm(perp1)
        perp2 = np.cross(tangent, perp1)
        perp2 = perp2 / np.linalg.norm(perp2)
    
        # 3. compute 4 corners of rectangle
        half_w = width / 2
        half_l = length / 2
    
        corner1 = p + perp1*half_w + tangent*half_l
        corner2 = p + perp1*half_w - tangent*half_l
        corner3 = p - perp1*half_w - tangent*half_l
        corner4 = p - perp1*half_w + tangent*half_l
    
        squares_corners.append(np.array([corner1, corner2, corner3, corner4]))

    return squares_corners

# bandpass filtering
def bandpass(data: np.ndarray,edges:list[float],sample_rate:float,poles: int=5):
    sos=scipy.signal.butter(poles,edges,'bandpass',fs=sample_rate,output='sos')
    filtered_data=scipy.signal.sosfiltfilt(sos,data)
    return filtered_data 






